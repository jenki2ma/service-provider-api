package com.greenpalm.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.hamcrest.CoreMatchers.is;

@ExtendWith(MockitoExtension.class)
class ServiceControllerTest {

    @Mock
    private ServiceRepository serviceRepository;

    private MockMvc mockMvc;

    @BeforeEach
    void init() {
        mockMvc = MockMvcBuilders.standaloneSetup(new ServiceController(serviceRepository)).build();
    }

    @Test
    void findsAllServices() throws Exception {
        String name = "Bob";
        Service service = new Service();
        service.setName(name);

        when(serviceRepository.findAll()).thenReturn(Collections.singletonList(service));

        mockMvc.perform(get("/v1/services"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name", is(name)));
    }

    @Test
    void testCreateService() throws Exception {
        String serviceName = "TestService";
        when(serviceRepository.save(any(service.class))).thenReturn(new Service());

        mockMVC.perform(MockMvcRequestBuilders.post("/v1/services")
                .param("name, serviceName")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.content().string("$[0].name"));
    }
    @Test
    void testUpdateService() throws Exception {
        String serviceId = "123";
        String serviceName = "UpdatedService";

        when(serviceRepository.existsById(anyLong())).thenReturn(true);
        when(serviceRepository.findById(anyLong())).thenReturn(java.util.Optional.of(new Service()));
        when(serviceRepository.save(any(Service.class))).thenReturn(new Service());

        mockMvc.perform(MockMvcRequestBuilders.put("/v1/services/{service-id}", serviceId))
                .param("name", serviceName)
                .contentType(MediaType.APPLICATION_JSON)
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.content().json("{\"name\":\"UpdatedService\"}"));
    }

    }

}

