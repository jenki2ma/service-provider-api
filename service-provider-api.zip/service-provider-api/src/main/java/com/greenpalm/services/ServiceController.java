package com.greenpalm.services;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ServiceController {

    private final ServiceRepository serviceRepository;

    @GetMapping("/v1/services")
    public ResponseEntity<List<Service>> findAll() {
        List<Service> services = serviceRepository.findAll();
        return ResponseEntity.ok(services);
    }

    @PostMapping("/v1/services")
    public ResponseEntity<?> createService(@RequestParam("name") String name) {
        Service service = new Service();
        service.setName(name);
        serviceRepository.save(service);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/v1/services/{service-id}")
    public ResponseEntity<?> updateService(@PathVariable("service-id") String serviceId, @RequestParam("name") String name) {
        if (serviceId == null || !serviceId.matches("\\d*")) {
            throw new RuntimeException("Invalid service ID");
        }
        long id = Long.parseLong(serviceId);

        if (serviceRepository.existsById(id)) {
            Service service = serviceRepository.findById(id).orElseThrow(() -> new RuntimeException("Error occurred while retrieving service"));
            service.setName(name);
            serviceRepository.save(service);
            return ResponseEntity.ok(service);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/v1/services")
    public ResponseEntity<?> deleteService(@RequestParam("id") String id) {
        if (id == null || !id.matches("\\d*")) {
            throw new RuntimeException("ID must be a digit.");
        }
        long idAsNumber = Long.parseLong(id);
        serviceRepository.deleteById(idAsNumber);
        return ResponseEntity.ok().build();
    }

}
