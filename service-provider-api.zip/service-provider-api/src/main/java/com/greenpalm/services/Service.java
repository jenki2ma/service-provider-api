package com.greenpalm.services;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Table(name = "services")
@Entity
@Getter
@Setter
public class Service {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "services_seq")
    @SequenceGenerator(name = "services_seq", sequenceName = "services_seq", allocationSize = 1)
    @Column(name = "id")
    private long id;

    @Column(name = "name")
    private String name;
}
