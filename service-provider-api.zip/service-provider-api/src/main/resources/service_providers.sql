CREATE TABLE services (
	id SERIAL PRIMARY KEY,
	name TEXT
);